`lsw` is a toolbox providing several functions I use on a daily basis
in gastroenterology and neurocscience.
